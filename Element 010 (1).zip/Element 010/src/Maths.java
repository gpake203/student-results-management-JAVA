import java.util.ArrayList;
import java.util.Objects;

public class Maths extends Student {

    public Maths(int year, String subject, String surname, String firstname, ArrayList grades) {
        super(year, subject, surname, firstname, grades);
    }
    public String determineGrade(int divisor,float total){
        String moduleResult = "";
        if (total/divisor<40) {
            moduleResult="Fail";
        }
        else if (total/divisor>=40 && total/divisor<60){
            moduleResult="Pass";
        }
        else if (total/divisor>=60 && total/divisor<=69){
            moduleResult="Merit";
        }
        else if (total/divisor>=70) {
            moduleResult ="Distinction";
        }
        return moduleResult;
    }

    public String getMaths(String moduleResult, float total, Maths mathsObj){
        moduleResult = mathsObj.determineGrade(12, total);
        String stream="";
        if (Objects.equals(subject,"Maths")){
            stream =(year + " " + subject + " " + firstname + " " + surname + " " + Math.ceil(total/12) + " " + moduleResult);
        }
        return stream;
    }
}
