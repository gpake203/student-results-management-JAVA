import java.io.*;
import java.util.*;

public class View { //VIEW (MVC design pattern is used in my application)
    public static void main(String[] args) {
        String path = "H:\\My Documents\\Data_File_For_Assignment.csv"; //required parameter for the BufferedReader object for reading a file
        String line = ""; //

        Scanner sc = new Scanner(System.in); //create scanner object, required to take user input
        System.out.println("MENU" +
                "\nEnter fail for a list of students that have failed an individual module" +
                "\nEnter all to print all students and their results" +
                "\nEnter a subject(geog,hist,math) or a year(2000-2005) to view individual results for it" +
                "\nEnter test to test program "); //list choices of what user can do- 4 of 6 optional functions are recorded here
        String menuOption = sc.nextLine(); //save user input as a string

        ArrayList<Student> allStudents = new ArrayList<Student>(); //create an arraylist to add each student to
        try {
            BufferedReader br = new BufferedReader(new FileReader(path)); //MODEL

            ArrayList<Integer> grades = null; //initialize array list to store student grades
            while ((line = br.readLine()) != null) { //while end of file hasn't been reached

                String[] item = line.split(","); //get the line of text first

                //get the year, subject, surname, and firstname from the relevant position in the file
                int year = Integer.parseInt(item[0]);
                String subject = item[1];
                String surname = item[2];
                String firstname = item[3];

                //create an int[] arrayList to store the student's grades.
                grades = new ArrayList<>();
                //loop through the remaining items in the list
                for (int i = 4; i < item.length; i++) {
                    grades.add(Integer.parseInt(item[i])); //convert to integer and add grades to arraylist
                }
                Student myStudent = new Student(year, subject, firstname, surname, grades); //create object of type Student
                float total=0; //set total to 0. this is to be used to add individual grades to, and divide by the number
                String moduleResult=""; //set the moduleResult to an empty string. this will be changed depending on the student's final result
                for (int i=0; i<grades.size(); i++) {
                    total+=Integer.parseInt(String.valueOf(grades.get(i))); //add the students' grades to total
                }
                // create objects for each type of student
                Geography geogObj = new Geography(year, subject, firstname, surname, grades);
                History histObj = new History(year, subject, firstname, surname, grades);
                Maths mathsObj = new Maths(year, subject, firstname, surname, grades);

                allStudents.add(myStudent); //add each student to allStudents

                /* FAIL
                 If the user selects this, the first names and surnames of all students
                 who have failed an individual module are printed to the console
                 */
                if (Objects.equals(menuOption,"fail")){
                    myStudent.getFailedStudents();
                }

                /*ALL
                If the user selects this, every student and their
                final result and classification are printed to the console
                 */
                if (Objects.equals(menuOption,"all")){
                    System.out.println(myStudent.getAll(geogObj,histObj,mathsObj,total,moduleResult));
                }

                /*SUBJECTS (geog,hist,math)
                If the user selects any of the inputs mentioned above,
                Every student that took that subject, their final result
                and classification are printed to the console
                 */
                if (Objects.equals(menuOption,"geog")){
                    moduleResult = geogObj.determineGrade(8, total);
                    if (Objects.equals(subject,"Geography")){
                        System.out.println(geogObj.getGeography(moduleResult,total,geogObj));
                    }
                }

                if (Objects.equals(menuOption,"hist")){
                    moduleResult = histObj.determineGrade(10, total);
                    if (Objects.equals(subject,"History")){
                        System.out.println(histObj.getHistory(moduleResult,total,histObj));
                    }
                }

                if (Objects.equals(menuOption,"math")){
                    moduleResult = mathsObj.determineGrade(12, total);
                    if (Objects.equals(subject,"Maths")){
                        System.out.println(mathsObj.getMaths(moduleResult,total,mathsObj));
                    }
                }

                /*YEARS (2000-2005)
                 * If the user selects any of the above inputs,
                 * Every student that graduated that year, their final result
                 * and classification are printed to the console
                */
                if (Objects.equals(menuOption,"2000")){
                    int divisor=myStudent.getDivisor(subject);
                    moduleResult= geogObj.determineGrade(divisor,total);
                    if (year==2000){
                        System.out.println(myStudent.get2000(myStudent,moduleResult,geogObj,total));
                        //System.out.println(divisor); (used for functional testing)
                    }
                }

                if (Objects.equals(menuOption,"2001")){
                    int divisor=myStudent.getDivisor(subject);
                    moduleResult= geogObj.determineGrade(divisor,total);
                    if (year==2001){
                        System.out.println(myStudent.get2001(myStudent,moduleResult,geogObj,total));
                    }
                }

                if (Objects.equals(menuOption,"2002")){
                    int divisor=myStudent.getDivisor(subject);
                    moduleResult= geogObj.determineGrade(divisor,total);
                    if (year==2002){
                        System.out.println(myStudent.get2002(myStudent,moduleResult,geogObj,total));
                    }
                }

                if (Objects.equals(menuOption,"2003")){
                    int divisor=myStudent.getDivisor(subject);
                    moduleResult= geogObj.determineGrade(divisor,total);
                    if (year==2003){
                        System.out.println(myStudent.get2003(myStudent,moduleResult,geogObj,total));
                    }
                }

                if (Objects.equals(menuOption,"2004")){
                    int divisor=myStudent.getDivisor(subject);
                    moduleResult= geogObj.determineGrade(divisor,total);
                    if (year==2003){
                        System.out.println(myStudent.get2004(myStudent,moduleResult,geogObj,total));
                    }
                }

                if (Objects.equals(menuOption,"2005")){
                    int divisor=myStudent.getDivisor(subject);
                    moduleResult= geogObj.determineGrade(divisor,total);
                    if (year==2005){
                        System.out.println(myStudent.get2005(myStudent,moduleResult,geogObj,total));
                    }
                }

                /*UNIT TESTING
                A series of automated tests to verify if each output
                for all methods previously used are correct
                If each value returned form the method matches the test data,
                "Pass" is printed to the console. If not, "Fail" is printed instead.
                 */
                if (Objects.equals(menuOption,"test")){
                    //testing getAll()
                    String test1=myStudent.getAll(geogObj,histObj,mathsObj,total,moduleResult);
                    if (Objects.equals(test1,"2000 History Braulio Valentine 44.0 Pass")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing get2000()
                    String test2=myStudent.get2000(myStudent,moduleResult,geogObj,total);
                    if (Objects.equals(test2,"2000 History Braulio Valentine 44.0 Pass")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing get2001()
                    String test3=myStudent.get2001(myStudent,moduleResult,geogObj,total);
                    if (Objects.equals(test3,"2001 Geography Alysia Barrett 45.0 Pass")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing get2002()
                    String test4=myStudent.get2002(myStudent,moduleResult,geogObj,total);
                    if (Objects.equals(test4,"2002 History Holmes Forte 56.0 Pass")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing get2003()
                    String test5=myStudent.get2003(myStudent,moduleResult,geogObj,total);
                    if (Objects.equals(test5,"2003 History Zettie Wittman 66.0 Merit")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing get2004()
                    String test6=myStudent.get2004(myStudent,moduleResult,geogObj,total);
                    if (Objects.equals(test6,"2004 History Derald Shipley 68.0 Merit")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing get2005()
                    String test7=myStudent.get2005(myStudent,moduleResult,geogObj,total);
                    if (Objects.equals(test7,"2005 Maths Gretchen Bustos 61.0 Merit ")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing getDivisor()
                    int test8=myStudent.getDivisor("History");
                    if (test8==10){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing getGeography()
                    String test9=geogObj.getGeography(moduleResult,total,geogObj);
                    if (Objects.equals(test9,"2001 Geography Alysia Barrett 45.0 Pass")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing getHistory()
                    String test10=histObj.getHistory(moduleResult,total,histObj);
                    if (Objects.equals(test10,"2000 History Braulio Valentine 44.0 Pass")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing getMaths()
                    String test11=mathsObj.getMaths(moduleResult,total,mathsObj);
                    if (Objects.equals(test11,"2005 Maths Gretchen Bustos 61.0 Merit")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    //testing determineGrade()
                    String test12=geogObj.determineGrade(8,total);
                    if (Objects.equals(test12,"Pass")){
                        System.out.println("Passed");
                    } else {System.out.println("Failed");}
                    System.out.println("End of testing");
                    break; //break to only run one instance of testing
                }
            }

            //close BufferedReader stream
            br.close();

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}

