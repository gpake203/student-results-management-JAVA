import java.util.ArrayList;
import java.util.Objects;
//Part of controller
public class Geography extends Student{
    //inherits from Student superclass, same attributes
    public Geography(int year, String subject, String surname, String firstname, ArrayList grades) {
        super(year, subject, surname, firstname, grades);
    }

    /*same commenting applies for these methods in history and maths classes
    though divisors will be different (history 10, maths 12) */

    /**
     * This method is used to determine the students result classification. The grade boundaries are:
     *<40% Fail,
     *40%-59% Pass
     *60%-69% Merit
     *>69% Distinction
     *<p>
     * The divisor passed into this method is predetermined depending on the subject. The total will be divided by this.
     * The moduleResult is set to whichever boundary the final result falls into, and is returned and displayed alongside other student information
     * depending on user input.
     *</p>
     * @param divisor
     * @param total
     * @return the relevant moduleResult depending on which bracket their final result falls into
     */
    public String determineGrade(int divisor,float total){
        String moduleResult = ""; //initialise moduleResult

        /*divide total by divisor
        determine which bracket the result of that falls between
        set moduleResult to the setting inside the relevant bracket
        return to function that called it, to be used in the stream
         */
        if (total/divisor<40) {
            moduleResult="Fail";
        }
        else if (total/divisor>=40 && total/divisor<60){
            moduleResult="Pass";
        }
        else if (total/divisor>=60 && total/divisor<=69){
            moduleResult="Merit";
        }
        else if (total/divisor>=70) {
            moduleResult ="Distinction";
        }
        return moduleResult;
    }

    /**This method prints the year, firstname, surname, subject, moduleResult and classification of every student who is studying Geography.
     * The divisor for the determineGrade function is set to 8 (they take 8 modules)
     *
     * @param moduleResult
     * @param total
     * @param geogObj
     * @return the student's year, subject, firstname, subject, total and moduleResult for all Geography students
     */
    public String getGeography(String moduleResult, float total, Geography geogObj){
        String stream="";
        moduleResult = geogObj.determineGrade(8, total); //pass 8 into determine grade as there are 8 modules
        if (Objects.equals(subject,"Geography")){ //skip over maths and history students, only set stream if they take geography
            stream =(year + " " + subject + " " + firstname + " " + surname + " " + Math.ceil(total / 8) + " " + moduleResult);
        }
        return stream;
    }

}
