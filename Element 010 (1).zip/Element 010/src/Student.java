import java.util.ArrayList;
import java.util.Objects;

//Part of controller
public class Student { //initialise properties that make up student
    int year;
    String subject;
    String surname;
    String firstname;
    ArrayList grades;

    public Student(int year,String subject,String firstname,String surname,ArrayList grades){ //encapsulation
                this.year=year;
                this.subject=subject;
                this.surname=surname;
                this.firstname=firstname;
                this.grades=grades;
    }


    //access and mutate properties
    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year=year;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject=subject;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname=surname;
    }

    public String getFirstname() {
        return firstname;
    }
    public void setFirstname(String firstname) {
        this.firstname=firstname;
    }

    public ArrayList getGrades() {
        return grades;
    }
    public void setGrades(ArrayList grades) {
        this.grades=grades;
    }


    public String get2005(Student myStudent, String moduleResult, Geography geogObj, float total){ //function to return all students who graduated in that year
        int divisor=0; //initialise divisor, needed to know what number to divide the grades total by
        String stream=""; //initialise empty string, to be returned if year matches
        divisor=myStudent.getDivisor(subject); //depending on the subject, the student will take either 8, 10 or 12 modules
        moduleResult= geogObj.determineGrade(divisor,total); //determine their grade classification (Fail,Pass,Merit,Distinction), pass in divisor calculate earlier and sum of grades
        if (year==2005){
            stream=year + " " + subject + " " + firstname + " " + surname + " " + Math.ceil(total / divisor) + " " + moduleResult; //set stream to include required data for that year
                                                                                //Math.ceil used to round up total to nearest integer
        }
        return stream; //return and use to print to console
    }

    //Years 2000-2004 are exactly the same
    public String get2004(Student myStudent, String moduleResult, Geography geogObj, float total){
        int divisor=0;
        String stream="";
        divisor=myStudent.getDivisor(subject);
        moduleResult= geogObj.determineGrade(divisor,total);
        if (year==2004){
            stream=year + " " + subject + " " + firstname + " " + surname + " " + Math.ceil(total / divisor) + " " + moduleResult;
        }
        return stream;
    }
    public String get2003(Student myStudent, String moduleResult, Geography geogObj, float total){
        int divisor=0;
        String stream="";
        divisor=myStudent.getDivisor(subject);
        moduleResult= geogObj.determineGrade(divisor,total);
        if (year==2003){
            stream=year + " " + subject + " " + firstname + " " + surname + " " + Math.ceil(total / divisor) + " " + moduleResult;
        }
        return stream;
    }
    public String get2002(Student myStudent, String moduleResult, Geography geogObj, float total){
        int divisor=0;
        String stream="";
        divisor=myStudent.getDivisor(subject);
        moduleResult= geogObj.determineGrade(divisor,total);
        if (year==2002){
            stream=year + " " + subject + " " + firstname + " " + surname + " " + Math.ceil(total / divisor) + " " + moduleResult;
        }
        return stream;
    }
    public String get2001(Student myStudent, String moduleResult, Geography geogObj, float total){
        int divisor=0;
        String stream="";
        divisor=myStudent.getDivisor(subject);
        moduleResult= geogObj.determineGrade(divisor,total);
        if (year==2001){
            stream=year + " " + subject + " " + firstname + " " + surname + " " + Math.ceil(total / divisor) + " " + moduleResult;
        }
        return stream;
    }

    /**
     *This method prints the year, firstname, surname, subject, moduleResult and classification of every student who graduated in the year 2000.
     * It uses the getDivisor method which depends on the subject, and determines the moduleResult (result classification) by using the divisor
     * @param myStudent
     * @param moduleResult
     * @param geogObj
     * @param total
     * @return the student's year, subject, firstname, subject, total and moduleResult for the year 2000
     */
    public String get2000(Student myStudent, String moduleResult, Geography geogObj, float total){
        int divisor=0;
        String stream="";
        divisor=myStudent.getDivisor(subject);
        moduleResult= geogObj.determineGrade(divisor,total);
        if (year==2000){
            stream=year + " " + subject + " " + firstname + " " + surname + " " + Math.ceil(total / divisor) + " " + moduleResult;
        }
        return stream;
    }

    /**
     * This method is used to know what number the total of the grades is to be divided by.
     * If the subject is Geography, the student’s grade total is divided by 8 to calculate their final result and so on.
     *
     * @param subject
     * @return the relevant divisor to divide the student's total of grades by
     */
    public int getDivisor(String subject){ //used to pass into determineGrade
        int divisor=0;
        if (Objects.equals(subject,"Geography")){
            divisor=8; //geog students take 8 modules, divide total by 8
        }
        else if (Objects.equals(subject,"History")){
            divisor=10; //history students take 10 modules, so divide total by 10
        }
        else if (Objects.equals(subject,"Maths")){
            divisor=12; //maths students take 12 modules, so divide total by 12
        }
        return divisor;
    }

    /**
     * This method prints the firstnames and surnames of the students who have failed an individual module (grade<40)
     * Nothing is returned, though the students are printed on the above condition
     */
    public void getFailedStudents(){ //return type is void becuase I only want to print inside the if statement
        for (int i=0;i<grades.size();i++) { //loop through each student's grades
            if (Integer.parseInt(String.valueOf(grades.get(i))) < 40) { //if an individual module result<40
                System.out.println(firstname+" "+surname); //print student's firstname and surname to the console
            }
        }
    }

    /**
     *
     * This method prints the year, firstname, surname, subject, final result and grade(moduleResult) of every student.
     * It calls the methods of getting results from an individual subject for each line of the file.
     *
     * @param geogObj
     * @param histObj
     * @param mathsObj
     * @param total
     * @param moduleResult
     * @return the student's year, subject, firstname, subject, total and moduleResult depending on the subject
     */
    public String getAll(Geography geogObj, History histObj, Maths mathsObj, float total, String moduleResult){
        String stream=""; //initialise empty string, to be returned if year matches
        if (Objects.equals(subject, "Geography")) {
            stream=(geogObj.getGeography(moduleResult,total,geogObj)); //loop through the whole file, set stream to relevant subject
        } else if (Objects.equals(subject, "History")) {
            stream=(histObj.getHistory(moduleResult,total,histObj));
        } else if (Objects.equals(subject, "Maths")) {
            stream=(mathsObj.getMaths(moduleResult,total,mathsObj));
        }
        return stream;
    }

}
